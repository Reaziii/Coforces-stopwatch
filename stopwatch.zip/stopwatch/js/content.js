window.onload = function () {
	if(document.getElementsByClassName("table-form").length){

		chrome.storage.sync.get(['my'],function(doo){
			var tt = doo.my;
			if(tt){
	
			var sidebar = document.getElementById("sidebar");
			var timer = document.createElement("div");
			timer.classList.add("roundbox");
			timer.classList.add("sidebox");
			timer.id = "timer";



			if (!(document.getElementsByClassName("verdict-accepted").length)) {
				timer.innerHTML = ' <div class="wrapper"><p><span id = "min">00</span>:<span id="seconds">00</span>:<span id="tens">00</span></p><button id="button-start">Start</button><button id="button-stop">Stop</button><button id="button-reset">Reset</button></div> ';
				sidebar.prepend(timer);
				clearInterval(Interval);
				Interval = setInterval(startTimer, 10);
				var seconds = 00; 
				var tens = 00; 
				var min = 00;
				var appendTens = document.getElementById("tens");
				var appendMin = document.getElementById("min");
				var appendSeconds = document.getElementById("seconds");
				var buttonStart = document.getElementById('button-start');
				var buttonStop = document.getElementById('button-stop');
				var buttonReset = document.getElementById('button-reset');
				var Interval ;
				buttonStart.onclick = function() {
					clearInterval(Interval);
				Interval = setInterval(startTimer, 10);
				}
				
				buttonStop.onclick = function() {
					clearInterval(Interval);
				}
		
			
				buttonReset.onclick = function() {
					clearInterval(Interval);
					tens = "00";
					seconds = "00";
					min = "00";
					appendTens.innerHTML = tens;
					appendSeconds.innerHTML = seconds;
					appendMin.innerHTML = min;

				}
				
		
		
				function startTimer () {
					tens++; 
				
					if(tens < 9){
						appendTens.innerHTML = "0" + tens;
					}
					
					if (tens > 9){
						appendTens.innerHTML = tens;
						
					} 
					
					if (tens > 99) {
						seconds++;
						appendSeconds.innerHTML = "0" + seconds;
						tens = 0;
						appendTens.innerHTML = "0" + 0;
					}
					if(seconds>59){
						min++;
						seconds = 0;
						if(min>9)appendMin.innerHTML = min;
						else appendMin.innerHTML = '0'+min;
						appendSeconds.innerHTML = "0" + 0;
					}

					
					if (seconds > 9){
						appendSeconds.innerHTML = seconds;
					}
				
				}
	
			}

	


			else {
				timer.innerHTML = '<div class = "wrapper" style="border-color:#0a0"><h1 class = "verdict-accepted" style="font-size:20px;line-height:3;">Accepted</div></div>'
				sidebar.prepend(timer);
			
			}

		}

		}
	)}
	else{
	alert("You have to login to use CF stopwatch!!");
	}



}