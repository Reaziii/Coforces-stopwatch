    chrome.storage.sync.get(['my'],function(doo){
        var now = doo.my;
        if(now){
            var v1 = document.getElementById("a1");
            v1.style.display = "none";

            var t1 = document.getElementById("turn-off");

            t1.onclick = function(){
                chrome.storage.sync.set({'my' : 0});
                location.reload();

            }

        }
        else{
            var v1 = document.getElementById("a2");
            v1.style.display = "none";

            var t1 = document.getElementById("turn-on");

            t1.onclick = function(){
                chrome.storage.sync.set({'my' : 1});
                location.reload();
            }

        }
    });






